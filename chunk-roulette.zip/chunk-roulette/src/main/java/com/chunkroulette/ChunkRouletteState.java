package com.chunkroulette;

/**
 * Хранит сид мира и считает индекс биома для чанка.
 * Результат зависит только от сида и координат чанка (без Random и без состояния),
 * поэтому он всегда одинаковый после перезапуска.
 */
public final class ChunkRouletteState {
    private static volatile boolean active = false;
    private static volatile long seed = 0L;

    private ChunkRouletteState() {}

    public static void enable(long worldSeed) {
        seed = worldSeed;
        active = true;
    }

    public static void disable() {
        active = false;
    }

    public static boolean isActive() {
        return active;
    }

    /** Индекс биома в списке для чанка (chunkX, chunkZ). */
    public static int pickIndex(int chunkX, int chunkZ, int size) {
        long h = seed;
        h ^= (long) chunkX * 0x9E3779B97F4A7C15L;
        h ^= (long) chunkZ * 0xC2B2AE3D27D4EB4FL;
        h = mix(h);
        return (int) Math.floorMod(h, (long) size);
    }

    // SplitMix64
    private static long mix(long z) {
        z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
        z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
        return z ^ (z >>> 31);
    }
}
