package com.chunkroulette.mixin;

import com.chunkroulette.ChunkRouletteState;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.biome.source.BiomeSource;
import net.minecraft.world.biome.source.MultiNoiseBiomeSource;
import net.minecraft.world.biome.source.util.MultiNoiseUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Mixin(MultiNoiseBiomeSource.class)
public abstract class MultiNoiseBiomeSourceMixin {

    // Кэш: список биомов этого источника (null = ещё не считали).
    @Unique
    private volatile List<RegistryEntry<Biome>> chunkroulette$biomes;

    // true, если это источник биомов Верхнего мира (в нём есть равнины).
    @Unique
    private volatile boolean chunkroulette$overworld;

    @Unique
    private volatile boolean chunkroulette$ready;

    @Inject(method = "getBiome", at = @At("HEAD"), cancellable = true)
    private void chunkroulette$pickBiome(int x, int y, int z, MultiNoiseUtil.MultiNoiseSampler noise,
                                         CallbackInfoReturnable<RegistryEntry<Biome>> cir) {
        if (!ChunkRouletteState.isActive()) {
            return;
        }
        if (!this.chunkroulette$ready) {
            this.chunkroulette$init();
        }
        if (!this.chunkroulette$overworld) {
            return; // Незер и прочее — обычная генерация.
        }
        List<RegistryEntry<Biome>> list = this.chunkroulette$biomes;
        // x и z здесь в «четвертях» блока: 4 четверти = 16 блоков = 1 чанк.
        int chunkX = x >> 2;
        int chunkZ = z >> 2;
        cir.setReturnValue(list.get(ChunkRouletteState.pickIndex(chunkX, chunkZ, list.size())));
    }

    @Unique
    private synchronized void chunkroulette$init() {
        if (this.chunkroulette$ready) {
            return;
        }
        List<RegistryEntry<Biome>> list = new ArrayList<>(((BiomeSource) (Object) this).getBiomes());
        // Сортировка по id, чтобы порядок был одинаковый при каждом запуске.
        list.sort(Comparator.comparing(e -> e.getKey().map(k -> k.getValue().toString()).orElse("")));
        boolean overworld = list.stream().anyMatch(e -> e.matchesKey(BiomeKeys.PLAINS));
        this.chunkroulette$biomes = list;
        this.chunkroulette$overworld = overworld && !list.isEmpty();
        this.chunkroulette$ready = true;
    }
}
