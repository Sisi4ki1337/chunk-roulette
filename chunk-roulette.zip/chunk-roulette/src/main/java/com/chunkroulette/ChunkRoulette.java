package com.chunkroulette;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ChunkRoulette implements ModInitializer {
    public static final String MOD_ID = "chunkroulette";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        // Сид мира берём до создания миров, чтобы он был готов к первой генерации.
        ServerLifecycleEvents.SERVER_STARTING.register(server -> {
            long seed = server.getSaveProperties().getGeneratorOptions().getSeed();
            ChunkRouletteState.enable(seed);
            LOGGER.info("Chunk Roulette enabled, seed {}", seed);
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> ChunkRouletteState.disable());
    }
}
