# Chunk Roulette

Fabric 1.21.1. Каждый чанк Верхнего мира получает один случайный ванильный биом.
Сид мира + координаты чанка → всегда один и тот же биом.

Нужно: Fabric Loader 0.16+, Fabric API, Java 21.

Сборка локально: `gradle wrapper`, потом `./gradlew build`. Jar: `build/libs/`.
Сборка на GitHub: см. `.github/workflows/build.yml` (запуск при push или вручную в Actions).
